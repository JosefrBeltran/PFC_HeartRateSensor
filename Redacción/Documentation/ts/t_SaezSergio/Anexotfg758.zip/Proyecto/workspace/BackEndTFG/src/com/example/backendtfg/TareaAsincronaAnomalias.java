package com.example.backendtfg;

import java.util.Arrays;
import java.util.List;

import com.example.backendtfg.clasepulsoendpoint.Clasepulsoendpoint;
import com.example.backendtfg.clasepulsoendpoint.Clasepulsoendpoint.ListClasePulso;
import com.example.backendtfg.clasepulsoendpoint.model.ClasePulso;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.json.jackson2.JacksonFactory;
import android.app.AlertDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.Toast;

public class TareaAsincronaAnomalias extends AsyncTask<Void, Void, Void> {

	private Context contexto;
	private String msError="";
	private Button moBoton;

	

	private List<ClasePulso> moDatos;

	private String msFecha1;
	private String msFecha2 ;
	private JDate moDate1;
	private JDate moDate2;
	private String msArritmia="";
	private int mlBradi;
	private int mlTaqui;

	private static final String uri = "content://elias.pulsaciones/pulsaciones";
	public static final Uri CONTENT_URI = Uri.parse(uri);

	public TareaAsincronaAnomalias(Context contexto, String psFecha1, String psFecha2, Button poBoton) throws FechaMalException {
		// TODO Auto-generated constructor stub
		this.contexto = contexto;
		moBoton = poBoton;
		msFecha1 = psFecha1;
		msFecha2 = psFecha2;
		moDate1 = new JDate(msFecha1);
		moDate2 = new JDate(msFecha2);
	}

	@Override
	protected Void doInBackground(Void... params) {
		try {

			Clasepulsoendpoint.Builder endpointBuilder = new Clasepulsoendpoint.Builder(
					AndroidHttp.newCompatibleTransport(), new JacksonFactory(), new HttpRequestInitializer() {
						public void initialize(HttpRequest httpRequest) {
						}
					});

			Clasepulsoendpoint endpoint = CloudEndpointUtils.updateBuilder(endpointBuilder).build();
			
			ListClasePulso loDatos = endpoint.listClasePulso();
			moDatos = loDatos.execute().getItems();
			Arrays.sort(moDatos.toArray(),new java.util.Comparator<Object>() {
			    public int compare(Object o1, Object o2) {
			    	return (int) (((ClasePulso)o2).getFecha().getValue() - ((ClasePulso)o1).getFecha().getValue());
			    }
			});		
			mlBradi = 0;
			mlTaqui= 0;
			for(ClasePulso loDato : moDatos){
				boolean lbcon = true;
				if(loDato.getFecha().getValue()<moDate1.getDate().getTime()){
					lbcon=false;
				}
				if(lbcon && loDato.getFecha().getValue()>moDate2.getDate().getTime()){
					lbcon=false;
				}
				if(lbcon && loDato.getPulso() < 60){
					mlBradi++;
				}
				if(lbcon && loDato.getPulso() > 120){
					mlTaqui++;
				}
			}
			
		} catch (Throwable e) {
			msError = e.toString();
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void onPostExecute(Void result) {
		try {
			moBoton.setEnabled(true);
			
			if(mlBradi>5){
				msArritmia="Bradicardia";
			}
			if(mlTaqui>5){
				msArritmia+=" Taquicardia";
			}
			
			if(msArritmia.equals("")){
				msArritmia="No tienes anomal�as";
			}
			
			AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(contexto);
			dlgAlert.setMessage(msArritmia);
			dlgAlert.setTitle("Tiene anomal�as?");
			dlgAlert.setPositiveButton("OK", null);
			dlgAlert.setCancelable(true);
			dlgAlert.create().show();
			
			
			if(msError.equals("")){
				Toast.makeText(contexto, "Proceso terminado correctamente, N�mero datos(" + String.valueOf(moDatos.size()) + ", bradicardia "+mlBradi+ ", taquicardia "+mlTaqui+")" , Toast.LENGTH_LONG).show();
			}else{
				Toast.makeText(contexto, msError + ", N�mero datos(" + String.valueOf(moDatos.size()) + ")", Toast.LENGTH_LONG).show();
			}
			
			
		} catch (Throwable e) {
			Toast.makeText(contexto, e.toString(), Toast.LENGTH_LONG).show();
			e.printStackTrace();
			Toast.makeText(contexto, msError + ", N�mero datos(" + String.valueOf(moDatos.size()) + ")", Toast.LENGTH_LONG).show();
		}
	}

}

package com.example.backendtfg;

import com.androidplot.xy.XYPlot;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;




public class MainActivity extends Activity {

	private Button moBoton;
	private XYPlot mySimpleXYPlot;
	private Button moBoton2;
	private Button mobuttonArritmia;
	private EditText moeditTextFecha1;
	private EditText moeditTextFecha2;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//Bot�n para actualizar la BD y para buscar anomal�as
		moBoton = (Button)this.findViewById(R.id.button1);
		moBoton2 = (Button)this.findViewById(R.id.button2);
		mobuttonArritmia = (Button)this.findViewById(R.id.buttonArritmia);
		
		//Bot�n para ejecutar la gr�fica
		mySimpleXYPlot = (XYPlot) findViewById(R.id.mySimpleXYPlot);
		
		
		//Campos destinados a las fechas
		moeditTextFecha1 = (EditText)this.findViewById(R.id.editTextFecha1);
		moeditTextFecha2 = (EditText)this.findViewById(R.id.editTextFecha2);
		
		
		moeditTextFecha1.setText( new JDate().getDia()  + "/" + new JDate().getMes()  + "/" + new JDate().getAno() );
		moeditTextFecha2.setText( new JDate().getDia()  + "/" + new JDate().getMes()  + "/" + new JDate().getAno() + " " + new JDate().getHora() + ":" + new JDate().getMinuto() + ":" + new JDate().getSegundo());
		        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	
	public void accederResolver(View v){
		
		//Bot�n activo para no estar tocando la pantalla y llamando cte a la tarea asincrona
		moBoton.setEnabled(false);
		
		//Acceso al conten provider
		
		TareaAsincronaResolver tarea = new TareaAsincronaResolver(this, (TextView)findViewById(R.id.tView1), (TextView)findViewById(R.id.tView2), moBoton);
		tarea.execute();
		
	}
	public void accederGrafico(View v){
		
		//Bot�n activo para no estar tocando la pantalla y llamando cte a la tarea asincrona
		moBoton2.setEnabled(false);
		
		//Acceso al conten provider
		
		TareaAsincronaListar tarea = new TareaAsincronaListar(this, mySimpleXYPlot , moBoton2);
		tarea.execute();
		
	}
	
	public void arritmia(View v){
		
		//Bot�n activo para no estar tocando la pantalla y llamando cte a la tarea asincrona
		mobuttonArritmia.setEnabled(false);
		
		//Acceso al conten provider
		
		TareaAsincronaAnomalias tarea;
		try {
			tarea = new TareaAsincronaAnomalias(this, moeditTextFecha1.getText().toString(), moeditTextFecha2.getText().toString(), mobuttonArritmia);
			tarea.execute();
		} catch (Exception e) {
			Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
		}
		
	}
	
}

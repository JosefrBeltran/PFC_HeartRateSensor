package com.example.backendtfg;

public class FechaMalException extends Exception {
	public FechaMalException(){
		super();
	}
	public FechaMalException(Exception e){
		super(e);
	}
}

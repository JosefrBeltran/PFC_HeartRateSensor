package com.example.backendtfg;

import com.example.backendtfg.clasepulsoendpoint.Clasepulsoendpoint;
import com.example.backendtfg.clasepulsoendpoint.model.ClasePulso;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.DateTime;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.BaseColumns;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class TareaAsincronaResolver extends AsyncTask<Void, Void, Void> {

	private Context contexto;
	private TextView t1;
	private TextView t2;
	private String mselcampo1 = "";
	private String mselcampo2 = "";
	private String msError="";
	private Button moBoton;

	public static final class Ejemplo implements BaseColumns {
		private Ejemplo() {
		}

		public static final String COL_CAMPO1 = "created_at";
		public static final String COL_CAMPO2 = "dato";
	}

	private static final String uri = "content://elias.pulsaciones/pulsaciones";
	public static final Uri CONTENT_URI = Uri.parse(uri);

	public TareaAsincronaResolver(Context contexto, TextView t1, TextView t2, Button poBoton) {
		// TODO Auto-generated constructor stub
		this.contexto = contexto;
		this.t1 = t1;
		this.t2 = t2;
		moBoton = poBoton;
	}

	@Override
	protected Void doInBackground(Void... params) {
		try {
			// TODO Auto-generated method stub
			String[] projection = new String[] { Ejemplo._ID, Ejemplo.COL_CAMPO1, Ejemplo.COL_CAMPO2 };
			Uri ejemploUri = CONTENT_URI;

			Clasepulsoendpoint.Builder endpointBuilder = new Clasepulsoendpoint.Builder(
					AndroidHttp.newCompatibleTransport(), new JacksonFactory(), new HttpRequestInitializer() {
						public void initialize(HttpRequest httpRequest) {
						}
					});

			Clasepulsoendpoint endpoint = CloudEndpointUtils.updateBuilder(endpointBuilder).build();

			ContentResolver cr = contexto.getContentResolver();
			Cursor cur = cr.query(ejemploUri, projection, null, null, null);
			if (cur.moveToFirst()) {
				int lBuenos=0;
				JDate loDate = new JDate();
				do {
					int elcampo0 = Integer
							.valueOf(String.valueOf(loDate.getMes()) + String.valueOf(loDate.getDia())
									+ String.valueOf(loDate.getHora()) + String.valueOf(loDate.getMinuto())
									+ String.valueOf(loDate.getSegundo()))
							+ cur.getInt(cur.getColumnIndex(Ejemplo._ID));
					mselcampo2 = cur.getString(cur.getColumnIndex(Ejemplo.COL_CAMPO1));
					loDate = new JDate(mselcampo2);
					int elcampo2 = cur.getInt(cur.getColumnIndex(Ejemplo.COL_CAMPO2));
					mselcampo2 = String.valueOf(elcampo2);
					ClasePulso datouno = new ClasePulso();
					datouno.setId(elcampo0);
					datouno.setFecha(new DateTime(loDate.getDate()));
					datouno.setPulso(elcampo2);

					try {
						endpoint.insertClasePulso(datouno).execute();
						lBuenos++;
					} catch (Throwable e) {
						msError = e.toString();
					}

				} while (cur.moveToNext());
				if(lBuenos>0){
					msError = "";
				}
			}
		} catch (Throwable e) {
			msError = e.toString();
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void onPostExecute(Void result) {
		try {
			//Activo el boton mientras ejecuta la funcion, para que est� desactivo antes y no acumular toques
			
			moBoton.setEnabled(true);
			t1.setText(mselcampo1);
			t2.setText(mselcampo2);
			if(msError.equals("")){
				//Lanzo un mensaje para saber que he acabado la tarea
				
				Toast.makeText(contexto, "Proceso terminado correctamente", Toast.LENGTH_LONG).show();
			}else{
				Toast.makeText(contexto, msError, Toast.LENGTH_LONG).show();
			}
		} catch (Throwable e) {
			
			e.printStackTrace();
		}
	}

	/*public TextView getT1() {
		return t1;
	}

	public void setT1(TextView t1) {
		this.t1 = t1;
	}

	public TextView getT2() {
		return t2;
	}

	public void setT2(TextView t2) {
		this.t2 = t2;
	}*/

}

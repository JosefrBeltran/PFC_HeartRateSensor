package com.example.backendtfg;

/*
		return (long) 0;
	}

	@Override
	protected Long doInBackground(Context... params) {
		// TODO Auto-generated method stub
		return null;
	}*/

import java.io.IOException;
import java.util.Date;

import com.example.backendtfg.clasepulsoendpoint.Clasepulsoendpoint;
import com.example.backendtfg.clasepulsoendpoint.model.ClasePulso;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.DateTime;

import android.content.Context;
import android.os.AsyncTask;

public class InsertService extends AsyncTask<Context, Integer, Long> {

	protected Long doInBackground(Context... contexts) {

		Clasepulsoendpoint.Builder endpointBuilder = new Clasepulsoendpoint.Builder(
				AndroidHttp.newCompatibleTransport(), new JacksonFactory(), new HttpRequestInitializer() {
					public void initialize(HttpRequest httpRequest) {
					}
				});

		Clasepulsoendpoint endpoint = CloudEndpointUtils.updateBuilder(endpointBuilder).build();

		try {

			ClasePulso datouno = new ClasePulso();
			datouno.setId(1);
			datouno.setFecha(new DateTime(new Date()));
			datouno.setPulso(85);
			// ClasePulso result = endpoint.insertClasePulso(datouno).execute();
			endpoint.insertClasePulso(datouno).execute();
//
//			ClasePulso datodos = new ClasePulso();
//			datodos.setId(2);
//			datodos.setFecha((long) 16);
//			datodos.setPulso(87);
//			// ClasePulso resultdos =
//			// endpoint.insertClasePulso(datodos).execute();
//			endpoint.insertClasePulso(datodos).execute();
//
//			ClasePulso datotres = new ClasePulso();
//			datodos.setId(3);
//			datodos.setFecha((long) 16);
//			datodos.setPulso(91);
//			// ClasePulso resultdos =
//			// endpoint.insertClasePulso(datodos).execute();
//			endpoint.insertClasePulso(datotres).execute();

		} catch (IOException e) {

			e.printStackTrace();

		}

		return (long) 0;

	}

}

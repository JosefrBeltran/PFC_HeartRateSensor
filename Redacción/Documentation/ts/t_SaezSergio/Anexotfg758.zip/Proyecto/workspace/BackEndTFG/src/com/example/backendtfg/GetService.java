package com.example.backendtfg;

import java.io.IOException;

import com.example.backendtfg.clasepulsoendpoint.Clasepulsoendpoint;
import com.example.backendtfg.clasepulsoendpoint.model.ClasePulso;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.json.jackson2.JacksonFactory;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

public class GetService extends AsyncTask<Context, Integer, Long> {

	protected TextView cajatextoget;

public TextView getCajatextoget() {
	return cajatextoget;
}

public void setCajatextoget(TextView cajatextoget) {
	this.cajatextoget = cajatextoget;
}

protected Long doInBackground(Context... contexts) {
	
Clasepulsoendpoint.Builder endpointBuilder = new Clasepulsoendpoint.Builder(AndroidHttp.newCompatibleTransport(), new JacksonFactory(), new HttpRequestInitializer() {
	
	public void initialize(HttpRequest httpRequest) { 
	
	}

});

Clasepulsoendpoint endpoint = CloudEndpointUtils.updateBuilder(endpointBuilder).build();

try {

	ClasePulso result = endpoint.getClasePulso((long) 2).execute();
	result.getPulso();
}

	catch (IOException e) {
		
			e.printStackTrace();
	}

return (long) 0;
}

public void onPostExecute(ClasePulso result){
	if (result != null){
		cajatextoget.setText(String.valueOf(result.getPulso()));
	}
	else{
		cajatextoget.setText("NaN");
	}
}
}
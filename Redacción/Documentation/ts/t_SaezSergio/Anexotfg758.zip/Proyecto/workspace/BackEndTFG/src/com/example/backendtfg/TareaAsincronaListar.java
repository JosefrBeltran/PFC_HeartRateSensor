package com.example.backendtfg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.PointLabelFormatter;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.XYSeries;
import com.example.backendtfg.clasepulsoendpoint.Clasepulsoendpoint;
import com.example.backendtfg.clasepulsoendpoint.Clasepulsoendpoint.ListClasePulso;
import com.example.backendtfg.clasepulsoendpoint.model.ClasePulso;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.json.jackson2.JacksonFactory;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.Toast;

public class TareaAsincronaListar extends AsyncTask<Void, Void, Void> {

	private Context contexto;

	private String msError="";
	private Button moBoton;

	private XYPlot mySimpleXYPlot;
	

	private List<ClasePulso> moDatos;


	private static final String uri = "content://elias.pulsaciones/pulsaciones";
	public static final Uri CONTENT_URI = Uri.parse(uri);

	public TareaAsincronaListar(Context contexto, XYPlot pySimpleXYPlot, Button poBoton) {
		// TODO Auto-generated constructor stub
		this.contexto = contexto;
		moBoton = poBoton;
		mySimpleXYPlot=pySimpleXYPlot;
	}

	@Override
	protected Void doInBackground(Void... params) {
		try {

			Clasepulsoendpoint.Builder endpointBuilder = new Clasepulsoendpoint.Builder(
					AndroidHttp.newCompatibleTransport(), new JacksonFactory(), new HttpRequestInitializer() {
						public void initialize(HttpRequest httpRequest) {
						}
					});

			Clasepulsoendpoint endpoint = CloudEndpointUtils.updateBuilder(endpointBuilder).build();
			
			ListClasePulso loDatos = endpoint.listClasePulso();
			moDatos = loDatos.execute().getItems();
			Arrays.sort(moDatos.toArray(),new java.util.Comparator<Object>() {
			    public int compare(Object o1, Object o2) {
			    	return (int) (((ClasePulso)o2).getFecha().getValue() - ((ClasePulso)o1).getFecha().getValue());
			    }
			});			
		} catch (Throwable e) {
			msError = e.toString();
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void onPostExecute(Void result) {
		try {
			moBoton.setEnabled(true);
			
			ArrayList<Number> loNumero = new ArrayList<Number>();

			for(ClasePulso loDato : moDatos){
				
				loNumero.add(new Integer(loDato.getPulso()));
				
			}
	        // A�adimos L�nea N�mero UNO:
	        XYSeries series1 = new SimpleXYSeries(
	        		loNumero,  // Array de datos
	                SimpleXYSeries.ArrayFormat.Y_VALS_ONLY, // S�lo valores verticales
	                "Series1"); // Nombre de la primera serie
	        
	        // Modificamos los colores de la primera serie
	        LineAndPointFormatter series1Format = new LineAndPointFormatter(
	        		Color.rgb(0, 200, 0),                   // Color de la l�nea
	                Color.rgb(0, 100, 0),                   // Color del punto
	                Color.rgb(150, 190, 150),                // Relleno
	                new PointLabelFormatter(Color.WHITE));             
	 	        
	        mySimpleXYPlot.clear();
	        mySimpleXYPlot.addSeries(series1, series1Format);
	        mySimpleXYPlot.redraw();
/*	        Number[] series2Numbers = {4, 6, 3, 8, 2, 10};
	        // Repetimos para la segunda serie
	        XYSeries series2 = new SimpleXYSeries(Arrays.asList(series2Numbers
	), SimpleXYSeries.ArrayFormat.Y_VALS_ONLY, "Series2");
	        // Repetimos para la segunda serie
	        mySimpleXYPlot.addSeries(series2, new LineAndPointFormatter
	(Color.rgb(0, 0, 200), Color.rgb(0, 0, 100), Color.rgb(150, 150, 190),                // Relleno
            new PointLabelFormatter(Color.WHITE)));*/
	 
//	        mySimpleXYPlot.setTicksPerRangeLabel(10);
	        
			if(msError.equals("")){
				Toast.makeText(contexto, "Proceso terminado correctamente, N�mero datos(" + String.valueOf(moDatos.size()) + ")" , Toast.LENGTH_LONG).show();
			}else{
				Toast.makeText(contexto, msError + ", N�mero datos(" + String.valueOf(moDatos.size()) + ")", Toast.LENGTH_LONG).show();
			}
		} catch (Throwable e) {
			Toast.makeText(contexto, e.toString(), Toast.LENGTH_LONG).show();
			e.printStackTrace();
			Toast.makeText(contexto, msError + ", N�mero datos(" + String.valueOf(moDatos.size()) + ")", Toast.LENGTH_LONG).show();
		}
	}

}

package com.example.backendtfg;

import java.util.Date;

import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

import com.google.appengine.api.datastore.Key;

@PersistenceCapable

public class ClasePulso {
	
	@PrimaryKey
	@Persistent(valueStrategy=IdGeneratorStrategy.IDENTITY)
	private Key key;
	
	@Persistent
	private int id;
	
	@Persistent
	private Date fecha;
	
	@Persistent
	private int pulso;
	
	
	public Date getfecha(){ return fecha;}
	public void setfecha(Date Fecha){fecha = Fecha;}
	
	public int getpulso() {return pulso;}
	public void setpulso(int Pulso) {pulso = Pulso;}
	
	public int getid() {return id;}
	public void setid(int Id) {id = Id;}	
	
	public Key getKey() { return key;}
	
public void setKey(Key key){
	this.key = key;
}
	

}
